</div>
<div class="footer" style="background-color: red;color: white;padding: 20px;text-align: center;position: relative;bottom: -10px;left: 0;">
	<?php echo u_copy; ?>

	
</div>
</div>

 <script src="js\jquery-3.1.0.min.js"></script>
<script src="js\bootstrap.min.js"></script>
</body>
</html>